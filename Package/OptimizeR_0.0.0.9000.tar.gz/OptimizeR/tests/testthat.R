library(testthat)
library(OptimizeR)

test_check("OptimizeR")
